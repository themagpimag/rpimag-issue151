from sense_hat import SenseHat
sense = SenseHat()

sense.show_letter("P", text_colour=[255, 255, 0], back_colour=[0, 0, 255])